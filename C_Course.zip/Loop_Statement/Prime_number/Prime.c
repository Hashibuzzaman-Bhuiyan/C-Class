#include<stdio.h>
void main()
{
    int n,c,t,f=0;
    printf("Enter a positive number without Zero :");
    scanf("%d",&n);
    if(n==1)
    {
        printf("Not Prime");
        f=1;
    }
 else if (n<=3)
 {
 printf("Prime Number");
 f=0;
 }

 else if(n>3)
 
 {
    for(c=2;c<n;c++)
    {
        t=n%c;
        if(t==0)
        {
            printf("Not Prime");
            f=1;
            break;
        }
    
    }
 }

 
else
    {
 printf("Prime Number");
       f=0;
    }

}