#include<stdio.h>
void main()
{
    int c,n,a,b,x;
    printf("How many numbers:");
    scanf("%d",&n);
    printf("Enter 1st value");
    scanf("%d",&a);
    x=a;
    for(c=2;c<=n;c++)
    {
        printf("Enter Another");
        scanf("%d",&b);
        if(x<b)
        x=b;
    }
    printf("Largest is %d",x);
}