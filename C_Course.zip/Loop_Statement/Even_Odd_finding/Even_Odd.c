#include<stdio.h>
void main()
{
    int n,c,a,x=0,y=0;
    printf("How many numbers :");
    scanf("%d",&n);
    for(c=1;c<=n;c++)
    {
        printf("Enter a value");
        scanf("%d",&a);
        
        if(a%2==0)
        x=x+1;
        else
        y=y+1;
        

    }
    printf("Total even%d and Total odd%d",x,y);
}