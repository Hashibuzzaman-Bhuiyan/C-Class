#include<stdio.h>
void main()
{
    float n,c,a,s=0;
    float average;
 printf("How many students:");
 scanf("%f",&n);
 
    for(c=1;c<=n;c++)
    {
        printf("Enter age:");
        scanf("%f",&a);
        s=s+a;
    }
    average=s/n;
    printf("Average age is %f",average);
}


