#include<stdio.h>

void main()
{
    int c,h,l,n;
    printf("Enter Highest number :");
    scanf("%d",&h);
    printf("Enter Lowest number :");
    scanf("%d",&l);
    printf("Negative Count difference :");
    scanf("%d",&n);

for(c=h;c>=l;c-=n)
{
   printf("%3d",c);
}
}