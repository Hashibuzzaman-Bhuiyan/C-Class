#include<stdio.h>
void main()
{
    float c,f;
    for(c=-40;c<=40;c=c+10)
    {
        f=(9*c+160)/5;
        printf("%f\n",f);
    }
}