#include<stdio.h>
void main()
{
    int s,n,c;
    printf("Enter a number");
    scanf("%d",&n);
    s=1;
    for(c=1;c<=n;c++)
    {
        s=s*c;
    printf("Factorial%d",s);
    }
}