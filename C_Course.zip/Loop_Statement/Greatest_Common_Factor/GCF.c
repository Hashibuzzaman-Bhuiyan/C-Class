#include<stdio.h>
void main()
{
    int l,s,t;
    printf("Enter Largest and Smallest Number");
    scanf("%d%d",&l,&s);
   do
   {
t=l%s;
l=s;
s=t;
   }
   while(s!=0);
   printf("Result is %d",l);
    
}