#include<stdio.h>
void main()
{
    int n,t,s=0;
    printf("Enter a Number");
    scanf("%d",&n);

do
{
t=n%10;
s=s+t;
n=n/10;
}
while (n!=0);
printf("Result is %d",s);

}