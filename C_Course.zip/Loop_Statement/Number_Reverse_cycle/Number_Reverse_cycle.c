#include<stdio.h>
void main ()
{
    int n,t;
    printf("Enter a Number");
    scanf("%d",&n);

    do
    {
        t=n%10;
        printf("%d",t);
        n=n/10;       
    } 
    while (n!=0);
    
}