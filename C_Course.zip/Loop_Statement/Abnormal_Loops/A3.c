#include<stdio.h>
void main()
{ 
    int c,k;
    for(c=1;c<=5;c++)
    {
        for(k=1;k<=c;k++)
        printf("%d",k);
        printf("\n");
    }
     for(c=4;c>=1;c--)
    {
        for(k=1;k<=c;k++)
        printf("%d",k);
        printf("\n");
    }
}