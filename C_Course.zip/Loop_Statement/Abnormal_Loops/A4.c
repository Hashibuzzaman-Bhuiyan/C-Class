#include <stdio.h>  
  void main()  
{  
    int i, j, row, k, m;  
    printf ("Enter a number to define the rows:");  
    scanf ("%d",&row);   
    printf("\n");    
    for ( i=1;i<=row;i++)  
    {   
        for (j=1;j<=row-i;j++)  
        {     
            printf (" ");   
        }  
        for ( k=1;k<=i;k++)  
        {  
            printf ("%d",k);  
        }  
        for (m=i-1;m>=1;m--)  
        {  
            printf("%d",m);
        }  
        printf ("\n");  
    }  
    
}  