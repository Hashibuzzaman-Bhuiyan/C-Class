#include<stdio.h>

void main()
{
    int c;
for(c=90;c>=10;c-=10)
{
   printf("%3d",c);
}
}