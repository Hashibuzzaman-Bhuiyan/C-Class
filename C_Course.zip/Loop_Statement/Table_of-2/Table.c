#include<stdio.h>
void main()
{
    int n,i,m;
    printf("Enter 2 ,for math table :");
    scanf("%d",&n);
    if(n==2)
{   printf("Here is the Table of 2 :\n");

    for(i=1;i<=10;i++)
    {
        m=n*i;
        printf("%d*%d=%d\n",n,i,m);
    }
}
else
printf("Invalid Number for the math table of 2");
}
