#include<stdio.h>
void main()
{
    char s[80];
    printf("Enter a Name");
    scanf("%s",s);
    printf("Hello %s",s);
}