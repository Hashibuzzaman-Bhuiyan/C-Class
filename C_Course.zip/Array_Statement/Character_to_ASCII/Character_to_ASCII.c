#include<stdio.h>
void main()
{
    char n;
    printf("Enter a Letter or Symbol");
    scanf("%c",&n);
    printf("ASCII code is : %d",n);

}