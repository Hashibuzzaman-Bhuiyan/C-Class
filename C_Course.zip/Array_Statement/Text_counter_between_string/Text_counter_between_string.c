#include<stdio.h>
void main()
{
    char s[80];
    int l;
    printf("Enter a String");
    scanf("%s,s");
    printf("Number of Character is %d",strlen(s));
}
