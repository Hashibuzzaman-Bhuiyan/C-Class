#include<stdio.h>
#include<conio.h>
void main()
{
int l,w,area;
printf("Length of area");
scanf("%d",&l);
printf("Width of area");
scanf("%d",&w);

area=l*w;
printf("\n Area of rectangle %d",area);
}