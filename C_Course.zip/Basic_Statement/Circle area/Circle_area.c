#include<stdio.h>
#include<math.h>
void main()

{
   float radius,area;

   printf("Enter radius");
   scanf("%f",&radius);

   area=3.1416*radius*radius;
   printf("Area of the Circle%f",area);

}