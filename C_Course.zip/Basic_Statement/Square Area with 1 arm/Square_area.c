#include<stdio.h>


void main()
{
  int a,area;

    printf("The value of equal arms :");
    scanf("%d",&a);

    area=(a*a);
    printf("The area is =%d",area);
}
