#include<stdio.h>
#include<math.h>
void main()
{
    float b,h,area;
    printf("Enter Base and Height");
    scanf("%f %f",&b,&h);

    area= 0.5*b*h;
    printf("Area is %f",area);
}